import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { Logger } from '@nestjs/common';
import { MicroserviceOptions, Transport } from '@nestjs/microservices';
import { join } from 'path'; // <-- Add this




async function bootstrap() {
  const app = await NestFactory.createMicroservice<MicroserviceOptions>(AppModule, {
    transport: Transport.GRPC,
    options: {
      package: 'app',
      protoPath: join(__dirname, '../src/hero/hero.proto'),
      url: 'localhost:5001'
    },
  });
  // const app = await NestFactory.createMicroservice(AppModule,microserviceOptions);
  
  await app.listen();
}
bootstrap();
// completed

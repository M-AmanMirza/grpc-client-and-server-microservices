// import { Metadata, ServerUnaryCall } from '@grpc/grpc-js';
import { Controller, Logger } from '@nestjs/common';
import { GrpcMethod } from '@nestjs/microservices';
import { AppService } from './app.service';

interface INumberArray { //      <--
  data: number[]; //             <--   Add these
} //                             <--   two
interface ISumOfNumberArray { // <--   interfaces
  sum: number; //                <--
} 
// interface HeroesService

@Controller()
export class AppController {
  private logger = new Logger('AppController');
  constructor(private readonly appService: AppService) {}

  @GrpcMethod('AppController', 'Accumulate')
  accumulate(numberArray: INumberArray, metadata: any): ISumOfNumberArray { // <--
    // this.logger.log('Adding ' + numberArray.data.toString()); //               <--  Should 
    let res = { sum: this.appService.accumulate(numberArray.data) };
    console.log('accumulate server', numberArray, res, new Date())
    return res; //          <--  like this
  } // 
  // @GrpcMethod('HeroesService', 'FindOne')
  // findOne(data: HeroById, _metadata: Metadata): Hero {
  //   const items = [
  //     { id: 1, name: 'John' },
  //     { id: 2, name: 'Doe' },
  //   ];
  //   return items.find(({ id }) => id === data.id);
  // }
}

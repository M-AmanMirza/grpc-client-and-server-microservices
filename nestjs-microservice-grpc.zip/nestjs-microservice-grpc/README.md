## Advantages
## Offers type safety  not passive like message broker
## Transmit data in binary much more efficient
## Auto generation of client code available for most languages

## DisAdvantages
## More compilcated setup then tcp and redis
## Transmit data is not human readable
## No CURL-Like tool for AD HOC testing 
## Will not work with some cloud Load balancers